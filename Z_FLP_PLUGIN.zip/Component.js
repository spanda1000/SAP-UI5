sap.ui.define([
	"sap/ui/core/Component",
	"sap/m/Button",
	"sap/m/ActionSheet"
], function(Component, Button, ActionSheet) {

	return Component.extend("com.example.FLPPlugins.Component", {

		init: function() {
			var renderer = sap.ushell.Container.getRenderer("fiori2");
			renderer.addHeaderEndItem("sap.m.Button", {
				id: "headerEnd",
				icon: "sap-icon://marketing-campaign",
				type: "Transparent",
				press: this._showLanguageMenu.bind(this)
			}, true, false);
			var title = document.getElementsByClassName("OneByOne sapMGT sapMPointer")[18].getAttribute("aria-label");
			if( title == "Record overtime↵On behalf of your team↵time-overtime" );
			{
				document.getElementsByClassName('sapMTileCntContent')[18].setAttribute('title','Record overtime');
				document.getElementsByClassName('sapMImageContent sapMTcInnerMarker')[18].setAttribute('title','Record overtime');
			} 
		},

		_showLanguageMenu: function(oEvent) {
			var oButton = oEvent.getSource();
			
			if (!this._oMenu) {
				this._oMenu = this._createMenu();
			}
			// var oDock = sap.ui.core.Popup.Dock;
			// this._oMenu.open(false, oButton, oDock.BeginTop, oDock.BeginBottom, oButton);
			this._oMenu.openBy(oButton);
		},

		_createMenu: function() {
			var l_URL = "http://source.tfl/HelpAndGuidance/HelpTopics/SAPHelp/341.aspx";
			var l_URL1 = "http://source.tfl/HelpAndGuidance/HelpTopics/SAPHelp/5867.aspx";
			var l_URL2 = "http://source.tfl/HelpAndGuidance/HelpTopics/SAPHelp/15340.aspx";
			var oMenu = new ActionSheet({
				showCancelButton: false,
				buttons: [
					new Button({
						text: "News",
						press: function() {
							//window.location.search = "sap-language=EN";
							window.open(l_URL);
							
						}
					}),
					new Button({
						text: "News1",
						press: function() {
							//window.location.search = "sap-language=EN";
							window.open(l_URL1);
						}
					}),
					new Button({
						text: "News2",
						press: function() {
							//window.location.search = "sap-language=NL";
							window.open(l_URL2);
						}
					})
				]
			});
			return oMenu;
		}
	});
});


